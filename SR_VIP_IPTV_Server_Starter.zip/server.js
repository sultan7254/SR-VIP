const express = require("express");
const crypto = require("crypto");

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER = process.env.SR_VIP_USER || "owner";
const PASS = process.env.SR_VIP_PASS || "CHANGE_THIS_PASSWORD";
const BASE_URL = process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`;

// Add only media URLs that you own or are licensed to distribute.
// Empty by default: this starter does not include films, series, or live channels.
const media = [];

const categories = [];
const validUser = (u, p) => u === USER && safeEqual(p, PASS);
function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function auth(req, res, next) {
  const u = req.query.username || req.body?.username;
  const p = req.query.password || req.body?.password;
  if (!validUser(u, p)) return res.status(401).json({ user_info: { auth: 0, message: "Invalid credentials" } });
  next();
}

app.get("/", (_req, res) => res.type("text").send("SR VIP server starter is running. Configure licensed media and credentials."));
app.get("/player_api.php", auth, (req, res) => {
  const action = req.query.action;
  const userInfo = {
    username: USER, password: "********", message: "SR VIP",
    auth: 1, status: "Active", exp_date: null, is_trial: "0",
    active_cons: "0", created_at: String(Math.floor(Date.now()/1000)),
    max_connections: "2", allowed_output_formats: ["m3u8", "ts"]
  };
  if (!action) return res.json({ user_info: userInfo, server_info: {
    url: req.hostname, port: String(PORT), https_port: "", server_protocol: req.protocol,
    rtmp_port: "", timezone: "Asia/Riyadh", timestamp_now: Math.floor(Date.now()/1000),
    time_now: new Date().toISOString()
  }});
  if (action === "get_live_categories" || action === "get_vod_categories" || action === "get_series_categories") return res.json(categories);
  if (action === "get_live_streams" || action === "get_vod_streams" || action === "get_series") return res.json([]);
  if (action === "get_short_epg") return res.json({ epg_listings: [] });
  return res.json([]);
});
app.get("/get.php", auth, (req, res) => {
  const type = String(req.query.type || "m3u_plus").toLowerCase();
  const output = String(req.query.output || "ts").toLowerCase();
  const lines = ["#EXTM3U"];
  for (const item of media) {
    if (!item.url || !item.name) continue;
    lines.push(`#EXTINF:-1 tvg-id="${item.id || ""}" group-title="${item.category || "SR VIP"}",${item.name}`);
    lines.push(item.url);
  }
  res.setHeader("Content-Type", "application/vnd.apple.mpegurl; charset=utf-8");
  res.setHeader("Content-Disposition", 'inline; filename="sr-vip.m3u"');
  res.send(lines.join("\n") + "\n");
});
app.get("/xmltv.php", auth, (_req, res) => {
  res.type("application/xml").send('<?xml version="1.0" encoding="UTF-8"?><tv></tv>');
});

app.listen(PORT, () => console.log(`SR VIP starter listening on ${PORT}`));
